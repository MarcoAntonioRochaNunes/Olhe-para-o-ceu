<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ApiController extends Controller
{
    public function index(Request $request){

        $cidade = $request->input('busca');
        $data = $this->ApiTempo($cidade);
        return view('welcome', compact('data'));

    }
    public function ApiTempo($cidade){
        // dd($cidade);

        $key = '103a61aafd3d04815d9a5b9c7f09900d';

        $city = $cidade;
        $country_code = 076;
        $limit = 5;

        $component = 'http://api.openweathermap.org/geo/1.0/direct?q='.$city.','.$country_code.'&limit='.$limit.'&appid='.$key.'';

        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $component);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $response = curl_exec($curl);

        $data = json_decode($response, true);

        curl_close($curl);

        foreach($data as $item){
            $state = $item['state'];
            if($state != null ){
                $la = $item['lat'];
                $lo = $item['lon'];

                $url = 'https://api.openweathermap.org/data/2.5/weather?lat='.$la.'&lon='.$lo.'&appid='.$key.'&units=metric&lang=pt_br';

                $curl = curl_init();

                curl_setopt($curl, CURLOPT_URL, $url);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

                $response = curl_exec($curl);

                $data = json_decode($response, true);

                // dd($data);
                return $data;
            }
        }

    }
}
