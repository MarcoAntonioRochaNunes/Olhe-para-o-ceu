import "./bootstrap";
<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integridade="sha384-kenU1KFdBIe4zVFQWjxhNVA3FJPliEoLevIkEM+KOJ8ySFVkJW84SXCWjUyLkNwT"
    crossorigin="anonymous"
>
    {" "}
</script>;
